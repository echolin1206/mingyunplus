# 明天下午操作清单 - 命运加法上线

## 准备事项
- [ ] 一台电脑 + 稳定的网络
- [ ] 一个 GitHub 账号（https://github.com/signup 免费注册）
- [ ] 一个 Vercel 账号（用 GitHub 账号一键登录 https://vercel.com）
- [ ] 你的域名 mingyunpluse.com 的注册商后台登录方式

## 3步上线

### Step 1: 把代码传到 GitHub（2分钟）
1. 打开 https://github.com/new
2. 仓库名填 `mingyunpluse`，点 Create
3. 点击 "uploading an existing file"
4. 将 `/mnt/agents/output/app/dist/public/` 文件夹内的所有文件拖进去上传
5. 点 "Commit changes"

### Step 2: 在 Vercel 部署（2分钟）
1. 打开 https://vercel.com/new
2. 点 "Import Git Repository"，选择 `mingyunpluse`
3. Framework Preset 选 `Vite`
4. Build Command: `npm run build`
5. Output Directory: `dist/public`
6. 点 "Deploy"

### Step 3: 绑定域名 mingyunpluse.com（3分钟）
1. Vercel 项目 → Settings → Domains
2. 添加 `mingyunpluse.com`
3. 在你的域名注册商后台添加 DNS 记录：
   - A记录：`@` → `76.76.21.21`
4. 等待 2-5 分钟，访问 https://mingyunpluse.com

## 完成后
- 网站上线！可以发朋友圈/小红书/抖音引流
- 当前是模拟支付模式，用户可以免费体验全部功能
- 后续接入真实微信支付时，只需要在 Vercel 加一个环境变量

## 遇到问题？
回到这个对话，我帮你排查。
