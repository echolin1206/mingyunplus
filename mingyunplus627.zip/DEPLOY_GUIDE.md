# 命运加法 - 完整部署指南

> 商户号：1627375792 | 公司：上海开运宝企业发展有限公司 | 域名：mingyunpluse.com

---

## 一、准备工作清单

在开始部署之前，请确保你已经有以下信息：

| 项目 | 状态 | 获取位置 |
|------|------|----------|
| 微信支付商户号 (1627375792) | ✅ 已有 | - |
| 商户API证书私钥 | ❓ 需要确认 | 微信商户平台 → 账户中心 → API安全 |
| 商户API证书序列号 | ❓ 需要确认 | 微信商户平台 → 账户中心 → API安全 |
| API v3 密钥 | ❓ 需要确认 | 微信商户平台 → 账户中心 → API安全 → 设置APIv3密钥 |
| 公众号/小程序 AppID | ❓ 需要确认 | 微信公众平台 |
| Cloudflare 账号 | ❓ 需要注册 | https://dash.cloudflare.com |
| Vercel 账号 | ❓ 需要注册 | https://vercel.com |
| GitHub 账号 | ❓ 需要注册 | https://github.com |

---

## 二、第一步：部署后端（Cloudflare Workers）

### 2.1 注册 Cloudflare 账号

1. 访问 https://dash.cloudflare.com/sign-up
2. 使用邮箱注册，验证邮箱
3. **不需要**添加站点，只需要 Workers 功能（免费额度足够）

### 2.2 安装 Wrangler CLI

在你的电脑上打开终端，执行：

```bash
# 需要 Node.js 18+ (如果还没安装，先装 https://nodejs.org)
npm install -g wrangler

# 登录 Cloudflare
wrangler login
# 会弹出一个浏览器窗口，授权登录即可
```

### 2.3 创建 KV 命名空间

```bash
cd /mnt/agents/output/api

# 创建 KV 命名空间
wrangler kv:namespace create "KV"
```

执行后会输出类似：
```
{ binding = "KV", id = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" }
```

把 `id` 的值记下来。

### 2.4 修改配置文件

打开 `wrangler.toml`，填入以下内容：

```toml
name = "mingyunpluse-api"
main = "src/index.ts"
compatibility_date = "2024-01-01"

[[kv_namespaces]]
binding = "KV"
id = "你刚才创建的 KV id"

[vars]
WECHAT_MCHID = "1627375792"
WECHAT_APPID = "你的公众号或小程序 AppID"
NOTIFY_URL = "https://api.mingyunpluse.com/api/callback"
FRONTEND_URL = "https://mingyunpluse.com"
```

### 2.5 设置敏感密钥（Secrets）

在 Cloudflare Dashboard 中设置，**不要在代码中写这些值**：

```bash
# 设置 API v3 密钥
wrangler secret put WECHAT_APIV3_KEY
# 然后粘贴你的 32 字节 API v3 密钥

# 设置商户API证书私钥
wrangler secret put WECHAT_PRIVATE_KEY
# 然后粘贴完整的私钥 PEM 内容（包含 BEGIN/END 行）

# 设置证书序列号
wrangler secret put WECHAT_SERIAL_NO
# 然后粘贴证书序列号
```

### 2.6 部署后端

```bash
wrangler deploy
```

部署成功后，你会得到一个 Worker URL：
```
https://mingyunpluse-api.your-account.workers.dev
```

记下这个地址，后续配置自定义域名 `api.mingyunpluse.com` 时会用到。

---

## 三、第二步：配置微信支付

### 3.1 申请/确认 API 证书

1. 登录 https://pay.weixin.qq.com
2. 账户中心 → API安全 → API证书
3. 如果还没有证书，点击"申请证书"，按流程操作
4. 下载 `apiclient_key.pem`（私钥文件）和 `apiclient_cert.pem`（证书文件）
5. 在"API证书"页面查看**证书序列号**（一串大写字母和数字）

### 3.2 设置 API v3 密钥

1. 账户中心 → API安全 → API v3 密钥
2. 点击"设置密钥"
3. 生成一个 32 字节的随机字符串（可以用密码生成器）
4. 务必保存好，只能设置一次，以后看不到

### 3.3 开通 H5 支付

1. 产品中心 → H5支付 → 申请开通
2. 填写信息：
   - 产品销售场景：虚拟服务
   - 对应网站地址：https://mingyunpluse.com
   - 网站名称：命运加法
3. 等待审核（通常 1-3 个工作日）

### 3.4 配置回调地址

1. 账户中心 → API安全 → 回调地址
2. 添加回调地址：`https://api.mingyunpluse.com/api/callback`
3. 确保域名能访问（部署后端后再配置也可以）

---

## 四、第三步：部署前端（Vercel）

### 4.1 创建 GitHub 仓库

1. 访问 https://github.com/new
2. 仓库名：`mingyunpluse`
3. 选择 Public 或 Private 都可以
4. 创建后，复制仓库地址

### 4.2 推送代码

```bash
cd /mnt/agents/output/app

# 初始化 git
git init
git add .
git commit -m "命运加法上线 v1.0"

# 关联远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/你的用户名/mingyunpluse.git

# 推送
git push -u origin main
```

### 4.3 在 Vercel 部署

1. 访问 https://vercel.com/new
2. 导入你的 GitHub 仓库 `mingyunpluse`
3. 配置：
   - Framework Preset: Vite
   - Build Command: `npm run build`
   - Output Directory: `dist/public`
4. 添加环境变量：
   - `VITE_API_BASE` = `https://api.mingyunpluse.com`
5. 点击 Deploy

部署完成后，你会得到一个 Vercel 域名，如 `mingyunpluse.vercel.app`

---

## 五、第四步：配置域名

### 5.1 前端域名 mingyunpluse.com

**在 Vercel 中添加：**

1. Vercel Dashboard → 你的项目 → Settings → Domains
2. 添加 `mingyunpluse.com`
3. Vercel 会提示你需要的 DNS 记录

**在你的域名注册商（阿里云/腾讯云/GoDaddy）后台：**

添加以下 DNS 记录：

| 类型 | 主机记录 | 记录值 |
|------|----------|--------|
| A | @ | 76.76.21.21 |
| CNAME | www | cname.vercel-dns.com |

或者如果 Vercel 提供了其他记录值，按 Vercel 的提示来。

### 5.2 后端域名 api.mingyunpluse.com

**在 Cloudflare 中添加：**

1. Cloudflare Dashboard → Workers & Pages
2. 找到你的 Worker `mingyunpluse-api`
3. Settings → Triggers → Custom Domains
4. 添加 `api.mingyunpluse.com`

**在域名注册商后台添加 DNS：**

| 类型 | 主机记录 | 记录值 |
|------|----------|--------|
| CNAME | api | mingyunpluse-api.your-account.workers.dev |

> 注意：如果你用 Cloudflare 托管 DNS，直接在 Cloudflare DNS 管理中添加 CNAME 即可。

---

## 六、第五步：验证部署

### 6.1 验证后端

```bash
# 测试后端是否运行
curl https://api.mingyunpluse.com/

# 期望返回
{"status":"ok","service":"命运加法支付服务"}
```

### 6.2 验证前端

访问 `https://mingyunpluse.com`，确认页面正常显示。

### 6.3 测试支付流程

1. 进入"会员中心"页面
2. 点击"立即开通终身会员"
3. 确认弹出支付窗口（显示二维码）
4. 用微信扫码测试支付

---

## 七、常见问题

### Q: 支付后页面没有跳转？

A: 检查浏览器控制台是否有跨域错误。确认 `FRONTEND_URL` 环境变量配置正确。

### Q: 微信扫码提示"商户号未开通H5支付"？

A: 需要在微信商户平台开通 H5 支付产品，审核需要 1-3 个工作日。

### Q: 回调通知没有收到？

A: 
1. 确认 `NOTIFY_URL` 是外网可访问的 HTTPS 地址
2. 在 Cloudflare Workers 日志中查看是否有请求到达
3. 确认 API v3 密钥正确

### Q: 如何查看支付日志？

A: 
```bash
cd /mnt/agents/output/api
wrangler tail
```

---

## 八、文件结构

```
/mnt/agents/output/
├── app/                    # 前端项目（React + Vite）
│   ├── src/
│   │   ├── pages/          # 页面组件
│   │   ├── components/     # 公共组件
│   │   ├── lib/api.ts      # 后端 API 封装
│   │   └── ...
│   ├── dist/public/        # 构建输出
│   └── package.json
│
├── api/                    # 后端项目（Cloudflare Workers）
│   ├── src/
│   │   ├── index.ts        # API 路由
│   │   └── wxpay.ts        # 微信支付封装
│   ├── wrangler.toml       # Cloudflare 配置
│   └── package.json
│
└── DEPLOY_GUIDE.md         # 本文件
```

---

## 九、技术支持

如果在部署过程中遇到任何问题：

1. **Cloudflare Workers 问题**：查看 https://developers.cloudflare.com/workers/
2. **微信支付问题**：查看 https://pay.weixin.qq.com/wiki/doc/apiv3/index.shtml
3. **Vercel 部署问题**：查看 https://vercel.com/docs

---

> 祝上线顺利！🎉
