import { eq, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { memberships } from "@db/schema";

export const membershipRouter = createRouter({
  // Get my current membership
  getMyMembership: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [membership] = await db
      .select()
      .from(memberships)
      .where(eq(memberships.userId, ctx.user.id))
      .limit(1);

    if (!membership) {
      return null;
    }

    // Check if single membership has expired
    if (
      membership.type === "single" &&
      membership.validUntil &&
      new Date(membership.validUntil) < new Date()
    ) {
      // Auto-expire
      await db
        .update(memberships)
        .set({ status: "expired" })
        .where(eq(memberships.id, membership.id));

      return { ...membership, status: "expired" as const };
    }

    return membership;
  }),

  // Check if user has access to a feature
  checkAccess: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [membership] = await db
      .select()
      .from(memberships)
      .where(
        and(
          eq(memberships.userId, ctx.user.id),
          eq(memberships.status, "active")
        )
      )
      .limit(1);

    if (!membership) {
      return { hasAccess: false, type: null as string | null };
    }

    // Check expiration for single
    if (
      membership.type === "single" &&
      membership.validUntil &&
      new Date(membership.validUntil) < new Date()
    ) {
      await db
        .update(memberships)
        .set({ status: "expired" })
        .where(eq(memberships.id, membership.id));

      return { hasAccess: false, type: null as string | null };
    }

    // Single type: check if already used
    if (membership.type === "single" && membership.singleUsed >= 1) {
      return { hasAccess: false, type: "single" as string | null };
    }

    return {
      hasAccess: true,
      type: membership.type,
    };
  }),

  // Use single membership (increment usage counter)
  useSingle: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    const [membership] = await db
      .select()
      .from(memberships)
      .where(
        and(
          eq(memberships.userId, ctx.user.id),
          eq(memberships.status, "active"),
          eq(memberships.type, "single")
        )
      )
      .limit(1);

    if (!membership) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "请先购买测算服务",
      });
    }

    if (membership.singleUsed >= 1) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "本次服务已使用，请重新购买",
      });
    }

    await db
      .update(memberships)
      .set({ singleUsed: membership.singleUsed + 1 })
      .where(eq(memberships.id, membership.id));

    return { success: true };
  }),
});
