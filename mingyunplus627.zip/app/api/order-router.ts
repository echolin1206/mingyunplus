import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { orders, memberships } from "@db/schema";

// Generate unique order number: ORD + timestamp + random
function generateOrderNo(): string {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `ORD${ts}${rand}`;
}

export const orderRouter = createRouter({
  // Create a new order
  create: authedQuery
    .input(
      z.object({
        type: z.enum(["single", "lifetime"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Check if user already has lifetime membership
      const existingMembership = await db
        .select()
        .from(memberships)
        .where(
          and(
            eq(memberships.userId, userId),
            eq(memberships.type, "lifetime"),
            eq(memberships.status, "active")
          )
        )
        .limit(1);

      if (existingMembership.length > 0) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "您已是终身会员，无需再次购买",
        });
      }

      const amount = input.type === "single" ? "9.90" : "39.00";
      const orderNo = generateOrderNo();

      const [order] = await db
        .insert(orders)
        .values({
          userId,
          orderNo,
          type: input.type,
          amount,
          status: "pending",
        })
        .$returningId();

      const createdOrder = await db
        .select()
        .from(orders)
        .where(eq(orders.id, order.id))
        .limit(1);

      return createdOrder[0];
    }),

  // Get order by ID
  getById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const [order] = await db
        .select()
        .from(orders)
        .where(
          and(eq(orders.id, input.id), eq(orders.userId, ctx.user.id))
        )
        .limit(1);

      if (!order) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "订单不存在",
        });
      }

      return order;
    }),

  // Get my orders
  getMyOrders: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db
      .select()
      .from(orders)
      .where(eq(orders.userId, ctx.user.id))
      .orderBy(desc(orders.createdAt));
  }),

  // Simulate payment (for demo - marks order as paid and activates membership)
  simulatePay: authedQuery
    .input(z.object({ orderId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Find the order
      const [order] = await db
        .select()
        .from(orders)
        .where(
          and(
            eq(orders.id, input.orderId),
            eq(orders.userId, userId),
            eq(orders.status, "pending")
          )
        )
        .limit(1);

      if (!order) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "订单不存在或已处理",
        });
      }

      // Update order status to paid
      await db
        .update(orders)
        .set({
          status: "paid",
          payMethod: "demo",
          paidAt: new Date(),
        })
        .where(eq(orders.id, order.id));

      // Activate or update membership
      if (order.type === "lifetime") {
        // Upsert lifetime membership
        const [existing] = await db
          .select()
          .from(memberships)
          .where(eq(memberships.userId, userId))
          .limit(1);

        if (existing) {
          await db
            .update(memberships)
            .set({
              type: "lifetime",
              status: "active",
              orderId: order.id,
              validUntil: null,
            })
            .where(eq(memberships.id, existing.id));
        } else {
          await db.insert(memberships).values({
            userId,
            type: "lifetime",
            status: "active",
            orderId: order.id,
          });
        }
      } else {
        // Single use - create or update membership
        const [existing] = await db
          .select()
          .from(memberships)
          .where(eq(memberships.userId, userId))
          .limit(1);

        // Set valid for 24 hours
        const validUntil = new Date();
        validUntil.setHours(validUntil.getHours() + 24);

        if (existing) {
          await db
            .update(memberships)
            .set({
              type: "single",
              status: "active",
              orderId: order.id,
              singleUsed: 0,
              validUntil,
            })
            .where(eq(memberships.id, existing.id));
        } else {
          await db.insert(memberships).values({
            userId,
            type: "single",
            status: "active",
            orderId: order.id,
            validUntil,
          });
        }
      }

      return { success: true, orderId: order.id };
    }),
});
