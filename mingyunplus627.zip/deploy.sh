#!/bin/bash
# 命运加法 - 一键部署脚本
# 用法: ./deploy.sh

set -e

echo "=========================================="
echo "  命运加法 - Vercel 一键部署"
echo "=========================================="
echo ""

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}错误: 未检测到 Node.js${NC}"
    echo "请先安装 Node.js: https://nodejs.org (建议 18+ 版本)"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
echo -e "${GREEN}✓ Node.js 已安装 (v$(node -v))${NC}"

# 检查 npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}错误: 未检测到 npm${NC}"
    exit 1
fi
echo -e "${GREEN}✓ npm 已安装${NC}"

# 安装 Vercel CLI（如果没有）
echo ""
echo -e "${YELLOW}Step 1: 检查 Vercel CLI...${NC}"
if ! command -v vercel &> /dev/null; then
    echo "正在安装 Vercel CLI..."
    npm install -g vercel
fi
echo -e "${GREEN}✓ Vercel CLI 已就绪${NC}"

# 登录 Vercel
echo ""
echo -e "${YELLOW}Step 2: 登录 Vercel...${NC}"
echo "如果浏览器没有自动打开，请手动访问显示的链接并点击授权"
vercel login || true

# 进入项目目录
cd "$(dirname "$0")/app"

# 安装依赖
echo ""
echo -e "${YELLOW}Step 3: 安装项目依赖...${NC}"
npm install

# 构建项目
echo ""
echo -e "${YELLOW}Step 4: 构建项目...${NC}"
npm run build

# 部署到 Vercel
echo ""
echo -e "${YELLOW}Step 5: 部署到 Vercel...${NC}"
echo "首次部署会提示配置，按以下选择："
echo "  - Set up and deploy? → 选 Y"
echo "  - Which scope? → 选你的账号"
echo "  - Link to existing project? → 选 N"
echo "  - Project name? → 输入 mingyunpluse"
echo ""

cd dist/public
vercel --prod

echo ""
echo "=========================================="
echo -e "${GREEN}  部署完成!${NC}"
echo "=========================================="
echo ""
echo "接下来绑定你的域名:"
echo "1. 打开 https://vercel.com/dashboard"
echo "2. 找到 mingyunpluse 项目"
echo "3. Settings → Domains → 添加 mingyunpluse.com"
echo "4. 按提示在你的域名商后台添加 DNS 记录"
echo ""
